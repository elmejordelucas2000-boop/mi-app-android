package com.example.myapp

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.R

/**
 * Adaptador para listar listas de reproducción en la Biblioteca.
 */
class PlaylistAdapter(
    private val context: Context,
    private var playlists: List<Playlist>,
    private var counts: Map<Long, Int>,
    private val onPlaylistClick: (Playlist) -> Unit,
    private val onDeleteClick: (Playlist) -> Unit
) : RecyclerView.Adapter<PlaylistAdapter.PlaylistViewHolder>() {

    fun updateData(newPlaylists: List<Playlist>, newCounts: Map<Long, Int>) {
        this.playlists = newPlaylists
        this.counts = newCounts
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PlaylistViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_playlist, parent, false)
        return PlaylistViewHolder(view)
    }

    override fun onBindViewHolder(holder: PlaylistViewHolder, position: Int) {
        holder.bind(playlists[position])
    }

    override fun getItemCount(): Int = playlists.size

    inner class PlaylistViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvName: TextView = itemView.findViewById(R.id.tv_playlist_name)
        private val tvCount: TextView = itemView.findViewById(R.id.tv_playlist_song_count)
        private val btnDelete: ImageButton = itemView.findViewById(R.id.btn_playlist_delete)

        fun bind(playlist: Playlist) {
            tvName.text = playlist.name
            val count = counts[playlist.id] ?: 0
            tvCount.text = "$count canciones"

            itemView.setOnClickListener {
                onPlaylistClick(playlist)
            }

            btnDelete.setOnClickListener {
                onDeleteClick(playlist)
            }
        }
    }
}
