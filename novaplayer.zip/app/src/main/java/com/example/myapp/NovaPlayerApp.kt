package com.example.myapp

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.util.Log

/**
 * Clase Application de NovaPlayer.
 * Inicializa CrashHandler, canales de notificación y base de datos.
 */
class NovaPlayerApp : Application() {

    companion object {
        const val CHANNEL_ID = "nova_playback_channel"
        const val CHANNEL_NAME = "NovaPlayer Reproductor"
        private const val TAG = "NovaPlayerApp"

        lateinit var instance: NovaPlayerApp
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this

        try {
            // Inicializar manejador de fallas
            CrashHandler.init(this)
            Log.d(TAG, "NovaPlayerApp iniciado con éxito.")

            // Crear canales de notificación para el servicio Foreground
            createNotificationChannel()

            // Precalentar base de datos
            AppDatabase.getDatabase(this)
        } catch (e: Exception) {
            Log.e(TAG, "Error durante la inicialización de la app", e)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Control de reproducción de música en primer plano"
                    setShowBadge(false)
                    lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
                }
                val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
                notificationManager?.createNotificationChannel(channel)
                Log.d(TAG, "Canal de notificación creado correctamente.")
            } catch (e: Exception) {
                Log.e(TAG, "Error al crear el canal de notificación", e)
            }
        }
    }
}
