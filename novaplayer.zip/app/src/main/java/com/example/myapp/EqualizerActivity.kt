package com.example.myapp

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.media.audiofx.Equalizer
import android.os.Bundle
import android.os.IBinder
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.example.R
import com.google.android.material.switchmaterial.SwitchMaterial

/**
 * Actividad dedicada para el Ecualizador DSP de 5 Bandas estilo Poweramp.
 */
class EqualizerActivity : AppCompatActivity() {

    private val TAG = "EqualizerActivity"

    private var musicService: MusicService? = null
    private var isBound = false

    private lateinit var switchEnable: SwitchMaterial
    private lateinit var spinnerPresets: Spinner
    private lateinit var seekBass: SeekBar
    private lateinit var seekVirtualizer: SeekBar

    private val seekBands = mutableListOf<SeekBar>()
    private val tvBandLabels = mutableListOf<TextView>()
    private val tvBandVals = mutableListOf<TextView>()

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as? MusicService.MusicBinder
            musicService = binder?.getService()
            isBound = true
            setupEqualizerUI()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            musicService = null
            isBound = false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_equalizer)

        val toolbar: Toolbar = findViewById(R.id.toolbar_equalizer)
        toolbar.setNavigationOnClickListener { finish() }

        bindViews()
    }

    private fun bindViews() {
        switchEnable = findViewById(R.id.switch_eq_enable)
        spinnerPresets = findViewById(R.id.spinner_eq_presets)
        seekBass = findViewById(R.id.seek_bass_boost)
        seekVirtualizer = findViewById(R.id.seek_virtualizer)

        seekBands.add(findViewById(R.id.seek_band1))
        seekBands.add(findViewById(R.id.seek_band2))
        seekBands.add(findViewById(R.id.seek_band3))
        seekBands.add(findViewById(R.id.seek_band4))
        seekBands.add(findViewById(R.id.seek_band5))

        tvBandLabels.add(findViewById(R.id.tv_band1_label))
        tvBandLabels.add(findViewById(R.id.tv_band2_label))
        tvBandLabels.add(findViewById(R.id.tv_band3_label))
        tvBandLabels.add(findViewById(R.id.tv_band4_label))
        tvBandLabels.add(findViewById(R.id.tv_band5_label))

        tvBandVals.add(findViewById(R.id.tv_band1_val))
        tvBandVals.add(findViewById(R.id.tv_band2_val))
        tvBandVals.add(findViewById(R.id.tv_band3_val))
        tvBandVals.add(findViewById(R.id.tv_band4_val))
        tvBandVals.add(findViewById(R.id.tv_band5_val))
    }

    private fun setupEqualizerUI() {
        val eq = musicService?.equalizer
        val bass = musicService?.bassBoost
        val virt = musicService?.virtualizer

        switchEnable.isChecked = eq?.enabled == true
        switchEnable.setOnCheckedChangeListener { _, isChecked ->
            eq?.enabled = isChecked
            bass?.enabled = isChecked
            virt?.enabled = isChecked
        }

        // Configurar Presets
        val presets = listOf("Personalizado", "Rock", "Pop", "Jazz", "Super Bass", "Plano")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, presets)
        spinnerPresets.adapter = adapter

        spinnerPresets.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                applyPreset(position)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        // Configurar Bandas
        val numBands = eq?.numberOfBands?.toInt() ?: 5
        val minLevel = eq?.bandLevelRange?.get(0) ?: -1500
        val maxLevel = eq?.bandLevelRange?.get(1) ?: 1500
        val range = (maxLevel - minLevel)

        for (i in 0 until minOf(5, numBands)) {
            val bandIdx = i.toShort()
            val freq = (eq?.getCenterFreq(bandIdx) ?: 1000) / 1000
            tvBandLabels[i].text = if (freq >= 1000) "${freq / 1000} kHz" else "$freq Hz"

            val curLevel = eq?.getBandLevel(bandIdx) ?: 0
            val progress = (((curLevel - minLevel).toFloat() / range) * 30).toInt()
            seekBands[i].progress = progress
            tvBandVals[i].text = "${curLevel / 100} dB"

            seekBands[i].setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, prog: Int, fromUser: Boolean) {
                    if (fromUser && eq != null) {
                        val newLevel = (minLevel + (prog.toFloat() / 30f) * range).toInt().toShort()
                        try {
                            eq.setBandLevel(bandIdx, newLevel)
                            tvBandVals[i].text = "${newLevel / 100} dB"
                        } catch (e: Exception) {
                            Log.e(TAG, "Error asignando nivel a banda $i", e)
                        }
                    }
                }

                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }

        // Bass Boost
        seekBass.progress = bass?.roundedStrength?.toInt() ?: 400
        seekBass.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser && bass?.strengthSupported == true) {
                    try {
                        bass.setStrength(progress.toShort())
                    } catch (e: Exception) {
                        Log.e(TAG, "Error configurando BassBoost", e)
                    }
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        // Virtualizer
        seekVirtualizer.progress = virt?.roundedStrength?.toInt() ?: 350
        seekVirtualizer.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser && virt?.strengthSupported == true) {
                    try {
                        virt.setStrength(progress.toShort())
                    } catch (e: Exception) {
                        Log.e(TAG, "Error configurando Virtualizer", e)
                    }
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    private fun applyPreset(presetIndex: Int) {
        val eq = musicService?.equalizer ?: return
        val gains = when (presetIndex) {
            1 -> intArrayOf(400, 200, -100, 200, 500) // Rock
            2 -> intArrayOf(-100, 200, 400, 200, -100) // Pop
            3 -> intArrayOf(300, 100, -200, 200, 400) // Jazz
            4 -> intArrayOf(700, 500, 100, 0, 0) // Super Bass
            5 -> intArrayOf(0, 0, 0, 0, 0) // Plano
            else -> return // Personalizado
        }

        for (i in gains.indices) {
            if (i < 5 && i < eq.numberOfBands) {
                try {
                    val bandIdx = i.toShort()
                    eq.setBandLevel(bandIdx, gains[i].toShort())
                    val progress = 15 + (gains[i] / 100)
                    seekBands[i].progress = progress.coerceIn(0, 30)
                    tvBandVals[i].text = "${gains[i] / 100} dB"
                } catch (e: Exception) {
                    Log.e(TAG, "Error aplicando preset", e)
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        val intent = Intent(this, MusicService::class.java)
        bindService(intent, connection, Context.BIND_AUTO_CREATE)
    }

    override fun onStop() {
        super.onStop()
        if (isBound) {
            unbindService(connection)
            isBound = false
        }
    }
}
