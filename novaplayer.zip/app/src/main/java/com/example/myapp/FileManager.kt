package com.example.myapp

import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.provider.MediaStore
import android.util.Log
import java.io.File

/**
 * Gestor de operaciones con archivos de música (renombrar, eliminar).
 */
object FileManager {

    private const val TAG = "FileManager"

    /**
     * Renombra un archivo de audio local de forma segura
     */
    fun renameFile(context: Context, originalPath: String, newNameWithoutExt: String): Pair<Boolean, String> {
        try {
            val file = File(originalPath)
            if (!file.exists()) {
                Log.e(TAG, "El archivo original no existe: $originalPath")
                return Pair(false, originalPath)
            }

            val extension = file.extension
            val sanitizedNewName = newNameWithoutExt.trim()
            if (sanitizedNewName.isBlank()) {
                return Pair(false, originalPath)
            }

            val parentDir = file.parentFile ?: return Pair(false, originalPath)
            val newFile = File(parentDir, "$sanitizedNewName.$extension")

            if (newFile.exists()) {
                Log.e(TAG, "Ya existe un archivo con ese nombre: ${newFile.absolutePath}")
                return Pair(false, originalPath)
            }

            val success = file.renameTo(newFile)
            if (success) {
                // Notificar a MediaStore para reindexar
                MediaScannerConnection.scanFile(
                    context,
                    arrayOf(originalPath, newFile.absolutePath),
                    arrayOf("audio/*"),
                    null
                )
                Log.d(TAG, "Archivo renombrado exitosamente a: ${newFile.absolutePath}")
                return Pair(true, newFile.absolutePath)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Excepción renombrando archivo: $originalPath", e)
        }
        return Pair(false, originalPath)
    }

    /**
     * Elimina un archivo de audio de forma segura
     */
    fun deleteAudioFile(context: Context, filePath: String): Boolean {
        try {
            val file = File(filePath)
            if (file.exists()) {
                val deleted = file.delete()
                if (deleted) {
                    try {
                        context.contentResolver.delete(
                            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                            "${MediaStore.Audio.Media.DATA} = ?",
                            arrayOf(filePath)
                        )
                    } catch (e: Exception) {
                        Log.e(TAG, "Error limpiando registro en MediaStore", e)
                    }
                    Log.d(TAG, "Archivo eliminado: $filePath")
                    return true
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error eliminando archivo: $filePath", e)
        }
        return false
    }
}
