package com.example.myapp

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.R
import kotlinx.coroutines.launch
import java.io.File

/**
 * Pantalla completa de reproducción de música estilo Poweramp de alta fidelidad.
 */
class PlayerActivity : AppCompatActivity(), MusicService.OnPlaybackChangeListener {

    private val TAG = "PlayerActivity"

    private var musicService: MusicService? = null
    private var isBound = false
    private lateinit var favoriteManager: FavoriteManager

    private lateinit var btnBack: ImageButton
    private lateinit var btnEq: ImageButton
    private lateinit var imgArt: ImageView
    private lateinit var tvTitle: TextView
    private lateinit var tvArtistAlbum: TextView
    private lateinit var tvTechInfo: TextView
    private lateinit var btnFavorite: ImageButton
    private lateinit var seekbar: SeekBar
    private lateinit var tvCurrentTime: TextView
    private lateinit var tvTotalTime: TextView
    private lateinit var btnShuffle: ImageButton
    private lateinit var btnPrev: ImageButton
    private lateinit var btnPlayPause: ImageButton
    private lateinit var btnNext: ImageButton
    private lateinit var btnRepeat: ImageButton

    private var isUserTrackingSeekbar = false
    private val handler = Handler(Looper.getMainLooper())
    private val updateProgressRunnable = object : Runnable {
        override fun run() {
            if (musicService != null && !isUserTrackingSeekbar) {
                val current = musicService!!.getCurrentPosition()
                val total = musicService!!.getDuration()
                if (total > 0) {
                    val progress = ((current.toDouble() / total) * 1000).toInt()
                    seekbar.progress = progress
                    tvCurrentTime.text = formatTime(current)
                    tvTotalTime.text = formatTime(total)
                }
            }
            handler.postDelayed(this, 500)
        }
    }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as? MusicService.MusicBinder
            musicService = binder?.getService()
            isBound = true
            musicService?.registerListener(this@PlayerActivity)

            val song = musicService?.getCurrentSong()
            updateUI(song, musicService?.isPlaying() == true)
            updateShuffleButton()
            updateRepeatButton()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            musicService = null
            isBound = false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)

        favoriteManager = FavoriteManager(this)
        bindViews()
        setupListeners()
    }

    private fun bindViews() {
        btnBack = findViewById(R.id.btn_back)
        btnEq = findViewById(R.id.btn_equalizer_shortcut)
        imgArt = findViewById(R.id.img_player_album_art)
        tvTitle = findViewById(R.id.tv_player_title)
        tvArtistAlbum = findViewById(R.id.tv_player_artist_album)
        tvTechInfo = findViewById(R.id.tv_audio_tech_info)
        btnFavorite = findViewById(R.id.btn_favorite_toggle)
        seekbar = findViewById(R.id.player_seekbar)
        tvCurrentTime = findViewById(R.id.tv_player_time_current)
        tvTotalTime = findViewById(R.id.tv_player_time_total)
        btnShuffle = findViewById(R.id.btn_shuffle)
        btnPrev = findViewById(R.id.btn_prev)
        btnPlayPause = findViewById(R.id.btn_play_pause)
        btnNext = findViewById(R.id.btn_next)
        btnRepeat = findViewById(R.id.btn_repeat)

        tvTitle.isSelected = true // Activar efecto marquee en TextView
    }

    private fun setupListeners() {
        btnBack.setOnClickListener { finish() }

        btnEq.setOnClickListener {
            val intent = Intent(this, EqualizerActivity::class.java)
            startActivity(intent)
        }

        btnPlayPause.setOnClickListener {
            musicService?.togglePlayPause()
        }

        btnPrev.setOnClickListener {
            musicService?.previous()
        }

        btnNext.setOnClickListener {
            musicService?.next()
        }

        btnShuffle.setOnClickListener {
            if (musicService != null) {
                musicService!!.isShuffle = !musicService!!.isShuffle
                updateShuffleButton()
            }
        }

        btnRepeat.setOnClickListener {
            if (musicService != null) {
                musicService!!.repeatMode = when (musicService!!.repeatMode) {
                    MusicService.RepeatMode.ALL -> MusicService.RepeatMode.ONE
                    MusicService.RepeatMode.ONE -> MusicService.RepeatMode.OFF
                    MusicService.RepeatMode.OFF -> MusicService.RepeatMode.ALL
                }
                updateRepeatButton()
            }
        }

        btnFavorite.setOnClickListener {
            val currentSong = musicService?.getCurrentSong()
            if (currentSong != null) {
                lifecycleScope.launch {
                    val isFav = favoriteManager.toggleFavorite(currentSong.id)
                    updateFavoriteButton(isFav)
                }
            }
        }

        seekbar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser && musicService != null) {
                    val total = musicService!!.getDuration()
                    val targetMs = ((progress.toDouble() / 1000) * total).toInt()
                    tvCurrentTime.text = formatTime(targetMs)
                }
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {
                isUserTrackingSeekbar = true
            }

            override fun onStopTrackingTouch(sb: SeekBar?) {
                if (musicService != null && sb != null) {
                    val total = musicService!!.getDuration()
                    val targetMs = ((sb.progress.toDouble() / 1000) * total).toInt()
                    musicService!!.seekTo(targetMs)
                }
                isUserTrackingSeekbar = false
            }
        })
    }

    private fun updateUI(song: Song?, isPlaying: Boolean) {
        runOnUiThread {
            try {
                if (song != null) {
                    tvTitle.text = song.title
                    tvArtistAlbum.text = "${song.artist} • ${song.album}"

                    val ext = song.getExtension()
                    val sizeMb = String.format("%.1f", song.size / (1024.0 * 1024.0))
                    tvTechInfo.text = "$ext • $sizeMb MB • 44.1 kHz • Hi-Res DSP"

                    lifecycleScope.launch {
                        val isFav = favoriteManager.isFavorite(song.id)
                        updateFavoriteButton(isFav)
                    }
                } else {
                    tvTitle.text = getString(R.string.no_song_playing)
                    tvArtistAlbum.text = getString(R.string.app_name)
                    tvTechInfo.text = "Hi-Res Audio Engine"
                    updateFavoriteButton(false)
                }

                val playPauseRes = if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play
                btnPlayPause.setImageResource(playPauseRes)
            } catch (e: Exception) {
                Log.e(TAG, "Error actualizando UI del reproductor", e)
            }
        }
    }

    private fun updateFavoriteButton(isFavorite: Boolean) {
        if (isFavorite) {
            btnFavorite.setImageResource(R.drawable.ic_favorite_filled)
            btnFavorite.setColorFilter(getColor(R.color.favorite_red))
        } else {
            btnFavorite.setImageResource(R.drawable.ic_favorite)
            btnFavorite.setColorFilter(getColor(R.color.text_secondary))
        }
    }

    private fun updateShuffleButton() {
        val shuffleOn = musicService?.isShuffle == true
        btnShuffle.setColorFilter(getColor(if (shuffleOn) R.color.accent_neon else R.color.text_secondary))
    }

    private fun updateRepeatButton() {
        when (musicService?.repeatMode) {
            MusicService.RepeatMode.ONE -> {
                btnRepeat.setImageResource(R.drawable.ic_repeat)
                btnRepeat.setColorFilter(getColor(R.color.accent_neon))
            }
            MusicService.RepeatMode.ALL -> {
                btnRepeat.setImageResource(R.drawable.ic_repeat)
                btnRepeat.setColorFilter(getColor(R.color.primary))
            }
            else -> {
                btnRepeat.setImageResource(R.drawable.ic_repeat)
                btnRepeat.setColorFilter(getColor(R.color.text_secondary))
            }
        }
    }

    private fun formatTime(millis: Int): String {
        val totalSeconds = (millis / 1000).coerceAtLeast(0)
        val minutes = totalSeconds / 60
        val seconds = totalSeconds % 60
        return String.format("%02d:%02d", minutes, seconds)
    }

    override fun onSongChanged(song: Song?) {
        updateUI(song, musicService?.isPlaying() == true)
    }

    override fun onPlaybackStateChanged(isPlaying: Boolean) {
        updateUI(musicService?.getCurrentSong(), isPlaying)
    }

    override fun onProgressUpdate(currentMs: Int, totalMs: Int) {
        // Manejado por el loop del Handler
    }

    override fun onStart() {
        super.onStart()
        val intent = Intent(this, MusicService::class.java)
        bindService(intent, connection, Context.BIND_AUTO_CREATE)
        handler.post(updateProgressRunnable)
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacks(updateProgressRunnable)
        if (isBound) {
            musicService?.unregisterListener(this)
            unbindService(connection)
            isBound = false
        }
    }
}
