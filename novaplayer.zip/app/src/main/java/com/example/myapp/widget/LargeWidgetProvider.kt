package com.example.myapp.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.util.Log

/**
 * AppWidgetProvider para el widget completo 4x2 estilo Poweramp.
 */
class LargeWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (appWidgetId in appWidgetIds) {
            try {
                WidgetHelper.updateLargeWidget(context, appWidgetManager, appWidgetId, currentSong = null, isPlaying = false)
            } catch (e: Exception) {
                Log.e("LargeWidgetProvider", "Error actualizando widget grande: $appWidgetId", e)
            }
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
    }
}
