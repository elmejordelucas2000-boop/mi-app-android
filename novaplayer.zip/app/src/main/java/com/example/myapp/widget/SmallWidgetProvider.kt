package com.example.myapp.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.util.Log

/**
 * AppWidgetProvider para el widget compacto 1x1.
 */
class SmallWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (appWidgetId in appWidgetIds) {
            try {
                WidgetHelper.updateSmallWidget(context, appWidgetManager, appWidgetId, isPlaying = false)
            } catch (e: Exception) {
                Log.e("SmallWidgetProvider", "Error actualizando widget: $appWidgetId", e)
            }
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
    }
}
