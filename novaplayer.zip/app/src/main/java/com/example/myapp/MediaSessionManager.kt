package com.example.myapp

import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.R

/**
 * Gestor de MediaSessionCompat y generación de notificaciones estilo MediaStyle.
 */
class MediaSessionManager(
    private val service: MusicService
) {
    private val TAG = "MediaSessionManager"
    var mediaSession: MediaSessionCompat? = null
        private set

    init {
        try {
            mediaSession = MediaSessionCompat(service, "NovaPlayerSession").apply {
                setFlags(
                    MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS or
                            MediaSessionCompat.FLAG_HANDLES_TRANSPORT_CONTROLS
                )
                setCallback(object : MediaSessionCompat.Callback() {
                    override fun onPlay() {
                        service.play()
                    }

                    override fun onPause() {
                        service.pause()
                    }

                    override fun onSkipToNext() {
                        service.next()
                    }

                    override fun onSkipToPrevious() {
                        service.previous()
                    }

                    override fun onSeekTo(pos: Long) {
                        service.seekTo(pos.toInt())
                    }
                })
                isActive = true
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error inicializando MediaSessionCompat", e)
        }
    }

    fun updatePlaybackState(isPlaying: Boolean, currentPosition: Long) {
        try {
            val state = if (isPlaying) PlaybackStateCompat.STATE_PLAYING else PlaybackStateCompat.STATE_PAUSED
            val playbackState = PlaybackStateCompat.Builder()
                .setActions(
                    PlaybackStateCompat.ACTION_PLAY or
                            PlaybackStateCompat.ACTION_PAUSE or
                            PlaybackStateCompat.ACTION_SKIP_TO_NEXT or
                            PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS or
                            PlaybackStateCompat.ACTION_SEEK_TO
                )
                .setState(state, currentPosition, 1.0f)
                .build()
            mediaSession?.setPlaybackState(playbackState)
        } catch (e: Exception) {
            Log.e(TAG, "Error actualizando PlaybackState", e)
        }
    }

    fun updateMetadata(song: Song?, albumArt: Bitmap?) {
        try {
            if (song == null) return
            val metadata = MediaMetadataCompat.Builder()
                .putString(MediaMetadataCompat.METADATA_KEY_TITLE, song.title)
                .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, song.artist)
                .putString(MediaMetadataCompat.METADATA_KEY_ALBUM, song.album)
                .putLong(MediaMetadataCompat.METADATA_KEY_DURATION, song.duration)
                .putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, albumArt)
                .build()
            mediaSession?.setMetadata(metadata)
        } catch (e: Exception) {
            Log.e(TAG, "Error actualizando metadata", e)
        }
    }

    fun buildNotification(song: Song?, isPlaying: Boolean): Notification {
        val title = song?.title ?: service.getString(R.string.no_song_playing)
        val artist = song?.artist ?: service.getString(R.string.app_name)

        // Intent para abrir MainActivity al tocar la notificación
        val contentIntent = Intent(service, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingContentIntent = PendingIntent.getActivity(
            service,
            0,
            contentIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Intents para los botones de la notificación
        val prevIntent = Intent(service, MusicService::class.java).apply { action = MusicService.ACTION_PREVIOUS }
        val pendingPrev = PendingIntent.getService(service, 1, prevIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val playPauseIntent = Intent(service, MusicService::class.java).apply { action = MusicService.ACTION_TOGGLE_PLAY }
        val pendingPlayPause = PendingIntent.getService(service, 2, playPauseIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val nextIntent = Intent(service, MusicService::class.java).apply { action = MusicService.ACTION_NEXT }
        val pendingNext = PendingIntent.getService(service, 3, nextIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val playPauseIcon = if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play
        val playPauseTitle = if (isPlaying) "Pause" else "Play"

        val defaultArt = BitmapFactory.decodeResource(service.resources, R.drawable.ic_nova_logo)

        val builder = NotificationCompat.Builder(service, NovaPlayerApp.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_music_note)
            .setLargeIcon(defaultArt)
            .setContentTitle(title)
            .setContentText(artist)
            .setContentIntent(pendingContentIntent)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(isPlaying)
            .addAction(R.drawable.ic_prev, "Previous", pendingPrev)
            .addAction(playPauseIcon, playPauseTitle, pendingPlayPause)
            .addAction(R.drawable.ic_next, "Next", pendingNext)
            .setStyle(
                androidx.media.app.NotificationCompat.MediaStyle()
                    .setMediaSession(mediaSession?.sessionToken)
                    .setShowActionsInCompactView(0, 1, 2)
            )

        return builder.build()
    }

    fun release() {
        try {
            mediaSession?.isActive = false
            mediaSession?.release()
        } catch (e: Exception) {
            Log.e(TAG, "Error liberando MediaSessionCompat", e)
        }
    }
}
