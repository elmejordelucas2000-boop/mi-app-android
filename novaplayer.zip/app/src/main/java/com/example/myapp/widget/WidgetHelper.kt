package com.example.myapp.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.example.R
import com.example.myapp.MainActivity
import com.example.myapp.MusicService
import com.example.myapp.Song

/**
 * Helper para actualizar widgets en la pantalla de inicio de Android.
 */
object WidgetHelper {

    fun updateAllWidgets(context: Context, currentSong: Song?, isPlaying: Boolean) {
        val appWidgetManager = AppWidgetManager.getInstance(context)

        // 1. Actualizar Widget Pequeño
        val smallWidgetIds = appWidgetManager.getAppWidgetIds(
            ComponentName(context, SmallWidgetProvider::class.java)
        )
        for (widgetId in smallWidgetIds) {
            updateSmallWidget(context, appWidgetManager, widgetId, isPlaying)
        }

        // 2. Actualizar Widget Grande
        val largeWidgetIds = appWidgetManager.getAppWidgetIds(
            ComponentName(context, LargeWidgetProvider::class.java)
        )
        for (widgetId in largeWidgetIds) {
            updateLargeWidget(context, appWidgetManager, widgetId, currentSong, isPlaying)
        }
    }

    fun updateSmallWidget(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        isPlaying: Boolean
    ) {
        val views = RemoteViews(context.packageName, R.layout.widget_small)

        val playPauseIntent = Intent(context, MusicService::class.java).apply {
            action = MusicService.ACTION_TOGGLE_PLAY
        }
        val pPlayPause = PendingIntent.getService(
            context,
            101,
            playPauseIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(R.id.widget_small_btn_play_pause, pPlayPause)

        val iconRes = if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play
        views.setImageViewResource(R.id.widget_small_btn_play_pause, iconRes)

        // Tocar el widget abre la app
        val openApp = Intent(context, MainActivity::class.java)
        val pOpen = PendingIntent.getActivity(
            context,
            100,
            openApp,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(R.id.widget_small_root, pOpen)

        appWidgetManager.updateAppWidget(appWidgetId, views)
    }

    fun updateLargeWidget(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        currentSong: Song?,
        isPlaying: Boolean
    ) {
        val views = RemoteViews(context.packageName, R.layout.widget_large)

        val title = currentSong?.title ?: context.getString(R.string.no_song_playing)
        val artist = currentSong?.artist ?: context.getString(R.string.app_name)

        views.setTextViewText(R.id.widget_title, title)
        views.setTextViewText(R.id.widget_artist, artist)

        val playPauseRes = if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play
        views.setImageViewResource(R.id.widget_btn_play_pause, playPauseRes)

        // Acciones
        val prevIntent = Intent(context, MusicService::class.java).apply { action = MusicService.ACTION_PREVIOUS }
        val pPrev = PendingIntent.getService(context, 201, prevIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        views.setOnClickPendingIntent(R.id.widget_btn_prev, pPrev)

        val playPauseIntent = Intent(context, MusicService::class.java).apply { action = MusicService.ACTION_TOGGLE_PLAY }
        val pPlay = PendingIntent.getService(context, 202, playPauseIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        views.setOnClickPendingIntent(R.id.widget_btn_play_pause, pPlay)

        val nextIntent = Intent(context, MusicService::class.java).apply { action = MusicService.ACTION_NEXT }
        val pNext = PendingIntent.getService(context, 203, nextIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        views.setOnClickPendingIntent(R.id.widget_btn_next, pNext)

        // Clic en el cuerpo del widget abre la app
        val openApp = Intent(context, MainActivity::class.java)
        val pOpen = PendingIntent.getActivity(
            context,
            200,
            openApp,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(R.id.widget_large_root, pOpen)

        appWidgetManager.updateAppWidget(appWidgetId, views)
    }
}
