package com.example.myapp

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Entidad Room para almacenar canciones marcadas como favoritas.
 */
@Entity(tableName = "favorites")
data class Favorite(
    @PrimaryKey
    val songId: Long,
    val addedAt: Long = System.currentTimeMillis()
)
