package com.example.myapp

import android.content.Context
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Manejador global de excepciones para evitar cierres inesperados silenciosos
 * y registrar los logs de fallas para depuración.
 */
class CrashHandler private constructor(private val context: Context) : Thread.UncaughtExceptionHandler {

    private val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()

    init {
        Thread.setDefaultUncaughtExceptionHandler(this)
    }

    override fun uncaughtException(thread: Thread, throwable: Throwable) {
        try {
            Log.e(TAG, "FATAL CRASH DETECTADO en hilo ${thread.name}: ${throwable.message}", throwable)
            saveCrashLog(throwable)
        } catch (e: Exception) {
            Log.e(TAG, "Error al guardar el crash log", e)
        } finally {
            defaultHandler?.uncaughtException(thread, throwable)
        }
    }

    private fun saveCrashLog(throwable: Throwable) {
        try {
            val sw = StringWriter()
            val pw = PrintWriter(sw)
            throwable.printStackTrace(pw)
            val stackTrace = sw.toString()

            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val filename = "crash_log_$timestamp.txt"
            val crashDir = File(context.filesDir, "crash_logs")
            if (!crashDir.exists()) {
                crashDir.mkdirs()
            }
            val logFile = File(crashDir, filename)
            FileOutputStream(logFile).use { fos ->
                fos.write("NovaPlayer Crash Report\nDate: $timestamp\n\n$stackTrace".toByteArray())
            }
            Log.d(TAG, "Crash log guardado exitosamente en: ${logFile.absolutePath}")
        } catch (e: Exception) {
            Log.e(TAG, "No se pudo escribir el archivo de crash log", e)
        }
    }

    companion object {
        private const val TAG = "NovaPlayer_Crash"

        fun init(context: Context) {
            CrashHandler(context.applicationContext)
        }
    }
}
