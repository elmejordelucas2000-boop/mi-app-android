package com.example.myapp

import android.content.Context
import android.util.Log

/**
 * Gestor de favoritos respaldado por Room.
 */
class FavoriteManager(context: Context) {

    private val favoriteDao = AppDatabase.getDatabase(context).favoriteDao()
    private val TAG = "FavoriteManager"

    suspend fun getFavoriteSongIds(): Set<Long> {
        return try {
            favoriteDao.getAllFavoriteSongIds().toSet()
        } catch (e: Exception) {
            Log.e(TAG, "Error obteniendo IDs de favoritos", e)
            emptySet()
        }
    }

    suspend fun isFavorite(songId: Long): Boolean {
        return try {
            favoriteDao.isFavorite(songId)
        } catch (e: Exception) {
            Log.e(TAG, "Error verificando favorito para $songId", e)
            false
        }
    }

    suspend fun toggleFavorite(songId: Long): Boolean {
        return try {
            val exists = favoriteDao.isFavorite(songId)
            if (exists) {
                favoriteDao.removeFavorite(songId)
                Log.d(TAG, "Canción $songId removida de favoritos")
                false
            } else {
                favoriteDao.addFavorite(Favorite(songId))
                Log.d(TAG, "Canción $songId agregada a favoritos")
                true
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error al alternar favorito para $songId", e)
            false
        }
    }
}
