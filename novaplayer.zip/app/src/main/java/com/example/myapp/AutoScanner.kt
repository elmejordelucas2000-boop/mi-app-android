package com.example.myapp

import android.content.ContentUris
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Escáner automático de música para almacenamiento interno y tarjetas SD.
 */
object AutoScanner {

    private const val TAG = "AutoScanner"

    private val SUPPORTED_EXTENSIONS = setOf("mp3", "flac", "wav", "m4a", "aac", "ogg", "opus")

    /**
     * Escanea todas las canciones de MediaStore y del sistema de archivos.
     */
    suspend fun scanMusic(context: Context): List<Song> = withContext(Dispatchers.IO) {
        val songList = mutableListOf<Song>()
        val seenPaths = HashSet<String>()

        try {
            // 1. Escaneo mediante MediaStore
            val projection = arrayOf(
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.ALBUM,
                MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.DATA,
                MediaStore.Audio.Media.ALBUM_ID,
                MediaStore.Audio.Media.SIZE,
                MediaStore.Audio.Media.DATE_ADDED
            )

            val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 5000"
            val sortOrder = "${MediaStore.Audio.Media.TITLE} ASC"

            val uri: Uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI

            context.contentResolver.query(uri, projection, selection, null, sortOrder)?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                val dateAddedCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)

                while (cursor.moveToNext()) {
                    try {
                        val path = cursor.getString(dataCol) ?: continue
                        val file = File(path)
                        if (file.exists() && !seenPaths.contains(path)) {
                            val id = cursor.getLong(idCol)
                            val title = cursor.getString(titleCol) ?: file.nameWithoutExtension
                            val artist = cursor.getString(artistCol) ?: "Artista Desconocido"
                            val album = cursor.getString(albumCol) ?: "Álbum Desconocido"
                            val duration = cursor.getLong(durationCol)
                            val albumId = cursor.getLong(albumIdCol)
                            val size = cursor.getLong(sizeCol)
                            val dateAdded = cursor.getLong(dateAddedCol)

                            songList.add(
                                Song(
                                    id = id,
                                    title = if (title.isBlank()) file.nameWithoutExtension else title,
                                    artist = if (artist.contains("<unknown>", true)) "Artista Desconocido" else artist,
                                    album = if (album.contains("<unknown>", true)) "Álbum Desconocido" else album,
                                    duration = duration,
                                    path = path,
                                    albumId = albumId,
                                    size = size,
                                    dateAdded = dateAdded
                                )
                            )
                            seenPaths.add(path)
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Error parseando pista en MediaStore", e)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error consultando MediaStore", e)
        }

        // 2. Escaneo de respaldo en carpetas comunes (Music, Download) y SD
        try {
            val rootsToScan = mutableListOf<File>()
            val internalMusic = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)
            val internalDownloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (internalMusic?.exists() == true) rootsToScan.add(internalMusic)
            if (internalDownloads?.exists() == true) rootsToScan.add(internalDownloads)

            // Tarjetas SD externas en /storage
            val storageDir = File("/storage")
            if (storageDir.exists() && storageDir.isDirectory) {
                storageDir.listFiles()?.forEach { sdDir ->
                    if (sdDir.isDirectory && sdDir.canRead() && !sdDir.name.equals("emulated", ignoreCase = true) && !sdDir.name.equals("self", ignoreCase = true)) {
                        rootsToScan.add(sdDir)
                    }
                }
            }

            for (root in rootsToScan) {
                scanDirectoryRecursively(root, songList, seenPaths, maxDepth = 4)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error en escaneo directo de carpetas", e)
        }

        // 3. Si no hay canciones (ej. emulador nuevo), inyectar pistas de demostración Hi-Fi locales
        if (songList.isEmpty()) {
            songList.addAll(generateDemoSongs(context))
        }

        Log.d(TAG, "Escaneo completado. Total canciones: ${songList.size}")
        songList
    }

    private fun scanDirectoryRecursively(
        dir: File,
        results: MutableList<Song>,
        seenPaths: MutableSet<String>,
        maxDepth: Int
    ) {
        if (maxDepth <= 0 || !dir.exists() || !dir.canRead()) return

        try {
            val files = dir.listFiles() ?: return
            for (file in files) {
                if (file.isDirectory && !file.name.startsWith(".")) {
                    scanDirectoryRecursively(file, results, seenPaths, maxDepth - 1)
                } else if (file.isFile && SUPPORTED_EXTENSIONS.contains(file.extension.lowercase())) {
                    val path = file.absolutePath
                    if (!seenPaths.contains(path)) {
                        seenPaths.add(path)
                        results.add(
                            Song(
                                id = file.hashCode().toLong(),
                                title = file.nameWithoutExtension.replace("_", " "),
                                artist = dir.name,
                                album = "Nova Local",
                                duration = 180000L,
                                path = path,
                                size = file.length(),
                                dateAdded = System.currentTimeMillis() / 1000
                            )
                        )
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error explorando carpeta: ${dir.absolutePath}", e)
        }
    }

    /**
     * Pistas de muestra de alta fidelidad cuando el dispositivo no tiene música descargada
     */
    private fun generateDemoSongs(context: Context): List<Song> {
        return listOf(
            Song(
                id = 101L,
                title = "Nova Synthwave Odyssey",
                artist = "Nova Sound Lab",
                album = "Cyber Neon",
                duration = 214000L,
                path = "demo_track_1",
                size = 5242880L
            ),
            Song(
                id = 102L,
                title = "Electric Aurora (Hi-Res)",
                artist = "Starlight Protocol",
                album = "Cosmic Waves",
                duration = 185000L,
                path = "demo_track_2",
                size = 8388608L
            ),
            Song(
                id = 103L,
                title = "Poweramp Bass Drive",
                artist = "Acoustic Matrix",
                album = "Subwoofer Masters",
                duration = 248000L,
                path = "demo_track_3",
                size = 6291456L
            ),
            Song(
                id = 104L,
                title = "Midnight Lounge Groove",
                artist = "Velvet Skyline",
                album = "Night City Sessions",
                duration = 192000L,
                path = "demo_track_4",
                size = 4718592L
            ),
            Song(
                id = 105L,
                title = "Quantum Resonance",
                artist = "Zero Kelvin",
                album = "Deep Spectrum",
                duration = 275000L,
                path = "demo_track_5",
                size = 9437184L
            )
        )
    }
}
