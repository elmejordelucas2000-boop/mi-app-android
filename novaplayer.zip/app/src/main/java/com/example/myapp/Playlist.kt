package com.example.myapp

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Entidad Room para representar una lista de reproducción.
 */
@Entity(tableName = "playlists")
data class Playlist(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * Entidad intermedia para asociar canciones con listas de reproducción.
 */
@Entity(tableName = "playlist_songs", primaryKeys = ["playlistId", "songId"])
data class PlaylistSongCrossRef(
    val playlistId: Long,
    val songId: Long
)
