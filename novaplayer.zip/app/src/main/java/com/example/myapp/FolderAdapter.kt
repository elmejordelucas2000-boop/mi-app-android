package com.example.myapp

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.R
import java.io.File

/**
 * Adaptador para listar carpetas o archivos en el Explorador.
 */
class FolderAdapter(
    private val context: Context,
    private var items: List<File>,
    private val onItemClick: (File) -> Unit
) : RecyclerView.Adapter<FolderAdapter.FolderViewHolder>() {

    fun updateData(newItems: List<File>) {
        this.items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FolderViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_folder, parent, false)
        return FolderViewHolder(view)
    }

    override fun onBindViewHolder(holder: FolderViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    inner class FolderViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvName: TextView = itemView.findViewById(R.id.tv_folder_name)
        private val tvCount: TextView = itemView.findViewById(R.id.tv_folder_count)
        private val imgIcon: ImageView = itemView.findViewById(R.id.img_folder_icon)

        fun bind(file: File) {
            tvName.text = file.name
            if (file.isDirectory) {
                imgIcon.setImageResource(R.drawable.ic_folder)
                val count = file.listFiles()?.size ?: 0
                tvCount.text = "$count elementos"
            } else {
                imgIcon.setImageResource(R.drawable.ic_music_note)
                val sizeKb = file.length() / 1024
                tvCount.text = "${sizeKb} KB • ${file.extension.uppercase()}"
            }

            itemView.setOnClickListener {
                onItemClick(file)
            }
        }
    }
}
