package com.example.myapp

import android.app.Dialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.R
import com.example.myapp.widget.WidgetHelper
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.chip.Chip
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.switchmaterial.SwitchMaterial
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Actividad Principal de NovaPlayer:
 * - 5 Tabs en BottomNavigationView (Reproductor, Biblioteca, Explorador, Ecualizador, Ajustes)
 * - Mini reproductor flotante persistente
 * - Escaneo automático de almacenamiento interno y tarjetas SD
 * - Gestión completa de Playlists y Favoritos con Room
 * - Operaciones de archivos (Renombrar / Eliminar)
 */
class MainActivity : AppCompatActivity(), MusicService.OnPlaybackChangeListener {

    private val TAG = "MainActivity"

    // Servicio de Música
    private var musicService: MusicService? = null
    private var isBound = false

    // Gestores de datos
    private lateinit var playlistManager: PlaylistManager
    private lateinit var favoriteManager: FavoriteManager

    // Vistas principales
    private lateinit var fragmentContainer: FrameLayout
    private lateinit var cardMiniPlayer: MaterialCardView
    private lateinit var bottomNav: BottomNavigationView

    // Mini reproductor
    private lateinit var miniTitle: TextView
    private lateinit var miniArtist: TextView
    private lateinit var miniAlbumArt: ImageView
    private lateinit var miniBtnPlayPause: ImageButton
    private lateinit var miniBtnNext: ImageButton

    // Listas y estado
    private var allSongs: List<Song> = emptyList()
    private var favoriteSongIds: Set<Long> = emptySet()
    private var allPlaylists: List<Playlist> = emptyList()
    private var playlistCounts: Map<Long, Int> = emptyMap()

    // Vistas infladas para las pestañas
    private var viewPlayer: View? = null
    private var viewLibrary: View? = null
    private var viewExplorer: View? = null
    private var viewEqualizer: View? = null
    private var viewSettings: View? = null

    // Adaptadores
    private var songAdapter: SongAdapter? = null
    private var folderAdapter: FolderAdapter? = null
    private var playlistAdapter: PlaylistAdapter? = null

    // Explorador de carpetas
    private var currentExplorerDir: File = Environment.getExternalStorageDirectory()

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as? MusicService.MusicBinder
            musicService = binder?.getService()
            isBound = true
            musicService?.registerListener(this@MainActivity)
            updateMiniPlayer(musicService?.getCurrentSong(), musicService?.isPlaying() == true)
            updatePlayerTabView(musicService?.getCurrentSong(), musicService?.isPlaying() == true)
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            musicService = null
            isBound = false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        playlistManager = PlaylistManager(this)
        favoriteManager = FavoriteManager(this)

        bindMainViews()
        setupMiniPlayer()
        setupNavigation()

        // Solicitar permisos y escanear
        if (PermissionManager.hasAllPermissions(this)) {
            startScan()
        } else {
            PermissionManager.requestPermissions(this)
            // Cargar pistas demo inmediatamente para que nunca esté vacío
            startScan()
        }

        // Iniciar y enlazar MusicService
        val serviceIntent = Intent(this, MusicService::class.java)
        startService(serviceIntent)
        bindService(serviceIntent, connection, Context.BIND_AUTO_CREATE)

        // Mostrar por defecto la pestaña de Biblioteca
        bottomNav.selectedItemId = R.id.nav_library
    }

    private fun bindMainViews() {
        fragmentContainer = findViewById(R.id.fragment_container)
        cardMiniPlayer = findViewById(R.id.card_mini_player)
        bottomNav = findViewById(R.id.bottom_navigation)

        miniTitle = findViewById(R.id.mini_song_title)
        miniArtist = findViewById(R.id.mini_song_artist)
        miniAlbumArt = findViewById(R.id.mini_album_art)
        miniBtnPlayPause = findViewById(R.id.mini_btn_play_pause)
        miniBtnNext = findViewById(R.id.mini_btn_next)
    }

    private fun setupMiniPlayer() {
        miniBtnPlayPause.setOnClickListener {
            musicService?.togglePlayPause()
        }

        miniBtnNext.setOnClickListener {
            musicService?.next()
        }

        cardMiniPlayer.setOnClickListener {
            // Abrir pantalla de reproducción completa
            val intent = Intent(this, PlayerActivity::class.java)
            startActivity(intent)
        }
    }

    private fun setupNavigation() {
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_player -> {
                    showPlayerTab()
                    cardMiniPlayer.visibility = View.GONE
                    true
                }
                R.id.nav_library -> {
                    showLibraryTab()
                    cardMiniPlayer.visibility = View.VISIBLE
                    true
                }
                R.id.nav_explorer -> {
                    showExplorerTab()
                    cardMiniPlayer.visibility = View.VISIBLE
                    true
                }
                R.id.nav_equalizer -> {
                    showEqualizerTab()
                    cardMiniPlayer.visibility = View.VISIBLE
                    true
                }
                R.id.nav_settings -> {
                    showSettingsTab()
                    cardMiniPlayer.visibility = View.VISIBLE
                    true
                }
                else -> false
            }
        }
    }

    // ==========================================
    // PESTAÑA 1: REPRODUCTOR
    // ==========================================
    private fun showPlayerTab() {
        fragmentContainer.removeAllViews()
        if (viewPlayer == null) {
            viewPlayer = layoutInflater.inflate(R.layout.fragment_player, fragmentContainer, false)
            setupPlayerTabViews(viewPlayer!!)
        }
        fragmentContainer.addView(viewPlayer)
        updatePlayerTabView(musicService?.getCurrentSong(), musicService?.isPlaying() == true)
    }

    private fun setupPlayerTabViews(v: View) {
        val btnPlayPause: ImageButton = v.findViewById(R.id.frag_btn_play_pause)
        val btnPrev: ImageButton = v.findViewById(R.id.frag_btn_prev)
        val btnNext: ImageButton = v.findViewById(R.id.frag_btn_next)
        val btnShuffle: ImageButton = v.findViewById(R.id.frag_btn_shuffle)
        val btnRepeat: ImageButton = v.findViewById(R.id.frag_btn_repeat)
        val btnFavorite: ImageButton = v.findViewById(R.id.frag_btn_favorite)
        val btnEq: ImageButton = v.findViewById(R.id.frag_btn_eq)
        val seekbar: SeekBar = v.findViewById(R.id.frag_seekbar)

        btnPlayPause.setOnClickListener { musicService?.togglePlayPause() }
        btnPrev.setOnClickListener { musicService?.previous() }
        btnNext.setOnClickListener { musicService?.next() }

        btnShuffle.setOnClickListener {
            if (musicService != null) {
                musicService!!.isShuffle = !musicService!!.isShuffle
                btnShuffle.setColorFilter(getColor(if (musicService!!.isShuffle) R.color.accent_neon else R.color.text_secondary))
            }
        }

        btnRepeat.setOnClickListener {
            if (musicService != null) {
                musicService!!.repeatMode = when (musicService!!.repeatMode) {
                    MusicService.RepeatMode.ALL -> MusicService.RepeatMode.ONE
                    MusicService.RepeatMode.ONE -> MusicService.RepeatMode.OFF
                    MusicService.RepeatMode.OFF -> MusicService.RepeatMode.ALL
                }
                val color = if (musicService!!.repeatMode != MusicService.RepeatMode.OFF) R.color.accent_neon else R.color.text_secondary
                btnRepeat.setColorFilter(getColor(color))
            }
        }

        btnFavorite.setOnClickListener {
            val song = musicService?.getCurrentSong()
            if (song != null) {
                lifecycleScope.launch {
                    val isFav = favoriteManager.toggleFavorite(song.id)
                    btnFavorite.setImageResource(if (isFav) R.drawable.ic_favorite_filled else R.drawable.ic_favorite)
                    btnFavorite.setColorFilter(getColor(if (isFav) R.color.favorite_red else R.color.text_secondary))
                    favoriteSongIds = favoriteManager.getFavoriteSongIds()
                    songAdapter?.updateFavorites(favoriteSongIds)
                }
            }
        }

        btnEq.setOnClickListener {
            bottomNav.selectedItemId = R.id.nav_equalizer
        }

        seekbar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {}
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {
                if (musicService != null && sb != null) {
                    val total = musicService!!.getDuration()
                    val targetMs = ((sb.progress.toDouble() / 1000) * total).toInt()
                    musicService!!.seekTo(targetMs)
                }
            }
        })
    }

    private fun updatePlayerTabView(song: Song?, isPlaying: Boolean) {
        val v = viewPlayer ?: return
        try {
            val tvTitle: TextView = v.findViewById(R.id.frag_tv_title)
            val tvArtist: TextView = v.findViewById(R.id.frag_tv_artist)
            val btnPlayPause: ImageButton = v.findViewById(R.id.frag_btn_play_pause)
            val btnFavorite: ImageButton = v.findViewById(R.id.frag_btn_favorite)

            if (song != null) {
                tvTitle.text = song.title
                tvArtist.text = "${song.artist} • ${song.album}"
                val isFav = favoriteSongIds.contains(song.id)
                btnFavorite.setImageResource(if (isFav) R.drawable.ic_favorite_filled else R.drawable.ic_favorite)
                btnFavorite.setColorFilter(getColor(if (isFav) R.color.favorite_red else R.color.text_secondary))
            } else {
                tvTitle.text = getString(R.string.no_song_playing)
                tvArtist.text = getString(R.string.app_name)
            }

            btnPlayPause.setImageResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        } catch (e: Exception) {
            Log.e(TAG, "Error actualizando vista de pestaña reproductor", e)
        }
    }

    // ==========================================
    // PESTAÑA 2: BIBLIOTECA
    // ==========================================
    private fun showLibraryTab() {
        fragmentContainer.removeAllViews()
        if (viewLibrary == null) {
            viewLibrary = layoutInflater.inflate(R.layout.fragment_library, fragmentContainer, false)
            setupLibraryTabViews(viewLibrary!!)
        }
        fragmentContainer.addView(viewLibrary)
    }

    private fun setupLibraryTabViews(v: View) {
        val recycler: RecyclerView = v.findViewById(R.id.recycler_library)
        val chipSongs: Chip = v.findViewById(R.id.chip_songs)
        val chipFavorites: Chip = v.findViewById(R.id.chip_favorites)
        val chipPlaylists: Chip = v.findViewById(R.id.chip_playlists)
        val etSearch: EditText = v.findViewById(R.id.et_search_library)
        val btnScan: ImageButton = v.findViewById(R.id.btn_scan_refresh)
        val fabNewPlaylist: FloatingActionButton = v.findViewById(R.id.fab_new_playlist)
        val emptyLayout: View = v.findViewById(R.id.layout_empty_state)
        val btnEmptyAction: MaterialButton = v.findViewById(R.id.btn_empty_action)

        recycler.layoutManager = LinearLayoutManager(this)

        songAdapter = SongAdapter(
            context = this,
            songs = allSongs,
            favoriteIds = favoriteSongIds,
            onSongClick = { song, index ->
                musicService?.setPlaylist(getCurrentFilteredSongs(), index)
            },
            onFavoriteClick = { song ->
                lifecycleScope.launch {
                    favoriteManager.toggleFavorite(song.id)
                    favoriteSongIds = favoriteManager.getFavoriteSongIds()
                    songAdapter?.updateFavorites(favoriteSongIds)
                }
            },
            onOptionClick = { song, actionId ->
                handleSongMenuOption(song, actionId)
            }
        )

        playlistAdapter = PlaylistAdapter(
            context = this,
            playlists = allPlaylists,
            counts = playlistCounts,
            onPlaylistClick = { playlist ->
                openPlaylistSongs(playlist)
            },
            onDeleteClick = { playlist ->
                lifecycleScope.launch {
                    playlistManager.deletePlaylist(playlist.id)
                    refreshPlaylists()
                }
            }
        )

        recycler.adapter = songAdapter

        chipSongs.setOnClickListener {
            fabNewPlaylist.visibility = View.GONE
            recycler.adapter = songAdapter
            songAdapter?.updateData(allSongs, favoriteSongIds)
            emptyLayout.visibility = if (allSongs.isEmpty()) View.VISIBLE else View.GONE
        }

        chipFavorites.setOnClickListener {
            fabNewPlaylist.visibility = View.GONE
            val favSongs = allSongs.filter { favoriteSongIds.contains(it.id) }
            recycler.adapter = songAdapter
            songAdapter?.updateData(favSongs, favoriteSongIds)
            emptyLayout.visibility = if (favSongs.isEmpty()) View.VISIBLE else View.GONE
        }

        chipPlaylists.setOnClickListener {
            fabNewPlaylist.visibility = View.VISIBLE
            recycler.adapter = playlistAdapter
            refreshPlaylists()
            emptyLayout.visibility = if (allPlaylists.isEmpty()) View.VISIBLE else View.GONE
        }

        btnScan.setOnClickListener { startScan() }
        btnEmptyAction.setOnClickListener { startScan() }

        fabNewPlaylist.setOnClickListener { showCreatePlaylistDialog() }

        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s?.toString()?.trim() ?: ""
                val filtered = if (query.isEmpty()) {
                    allSongs
                } else {
                    allSongs.filter {
                        it.title.contains(query, ignoreCase = true) ||
                                it.artist.contains(query, ignoreCase = true) ||
                                it.album.contains(query, ignoreCase = true)
                    }
                }
                songAdapter?.updateData(filtered, favoriteSongIds)
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun getCurrentFilteredSongs(): List<Song> {
        val chipFav = viewLibrary?.findViewById<Chip>(R.id.chip_favorites)
        return if (chipFav?.isChecked == true) {
            allSongs.filter { favoriteSongIds.contains(it.id) }
        } else {
            allSongs
        }
    }

    private fun handleSongMenuOption(song: Song, actionId: Int) {
        when (actionId) {
            R.id.action_play_next -> {
                musicService?.songList?.add((musicService?.currentSongIndex ?: 0) + 1, song)
                Toast.makeText(this, "Se reproducirá a continuación", Toast.LENGTH_SHORT).show()
            }
            R.id.action_add_to_playlist -> {
                showAddToPlaylistDialog(song)
            }
            R.id.action_rename_file -> {
                showRenameDialog(song)
            }
            R.id.action_delete_file -> {
                showDeleteConfirmDialog(song)
            }
        }
    }

    private fun showAddToPlaylistDialog(song: Song) {
        lifecycleScope.launch {
            val playlists = playlistManager.getPlaylists()
            if (playlists.isEmpty()) {
                showCreatePlaylistDialog(song)
            } else {
                val names = playlists.map { it.name }.toTypedArray()
                AlertDialog.Builder(this@MainActivity)
                    .setTitle(R.string.add_to_playlist)
                    .setItems(names) { _, which ->
                        val selected = playlists[which]
                        lifecycleScope.launch {
                            playlistManager.addSongToPlaylist(selected.id, song.id)
                            Toast.makeText(this@MainActivity, "Agregado a ${selected.name}", Toast.LENGTH_SHORT).show()
                            refreshPlaylists()
                        }
                    }
                    .setPositiveButton(R.string.dialog_new_playlist) { _, _ ->
                        showCreatePlaylistDialog(song)
                    }
                    .setNegativeButton(R.string.dialog_cancel, null)
                    .show()
            }
        }
    }

    private fun showCreatePlaylistDialog(songToAdd: Song? = null) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_create_playlist, null)
        val etName: TextInputEditText = dialogView.findViewById(R.id.et_playlist_name)
        val btnCancel: MaterialButton = dialogView.findViewById(R.id.btn_cancel_playlist)
        val btnSave: MaterialButton = dialogView.findViewById(R.id.btn_save_playlist)

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .create()

        btnCancel.setOnClickListener { dialog.dismiss() }
        btnSave.setOnClickListener {
            val name = etName.text?.toString()?.trim() ?: ""
            if (name.isNotEmpty()) {
                lifecycleScope.launch {
                    val id = playlistManager.createPlaylist(name)
                    if (songToAdd != null && id > 0) {
                        playlistManager.addSongToPlaylist(id, songToAdd.id)
                    }
                    refreshPlaylists()
                    dialog.dismiss()
                }
            }
        }
        dialog.show()
    }

    private fun showRenameDialog(song: Song) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_rename, null)
        val etName: TextInputEditText = dialogView.findViewById(R.id.et_new_file_name)
        val btnCancel: MaterialButton = dialogView.findViewById(R.id.btn_cancel_rename)
        val btnSave: MaterialButton = dialogView.findViewById(R.id.btn_save_rename)

        etName.setText(song.title)

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .create()

        btnCancel.setOnClickListener { dialog.dismiss() }
        btnSave.setOnClickListener {
            val newName = etName.text?.toString()?.trim() ?: ""
            if (newName.isNotEmpty()) {
                val result = FileManager.renameFile(this, song.path, newName)
                if (result.first) {
                    Toast.makeText(this, "Archivo renombrado exitosamente", Toast.LENGTH_SHORT).show()
                    startScan()
                } else {
                    Toast.makeText(this, "No se pudo renombrar el archivo", Toast.LENGTH_SHORT).show()
                }
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun showDeleteConfirmDialog(song: Song) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_delete_confirm, null)
        val tvTarget: TextView = dialogView.findViewById(R.id.tv_delete_target_name)
        val btnCancel: MaterialButton = dialogView.findViewById(R.id.btn_cancel_delete)
        val btnConfirm: MaterialButton = dialogView.findViewById(R.id.btn_confirm_delete)

        tvTarget.text = "¿Eliminar '${song.title}' de forma permanente?"

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .create()

        btnCancel.setOnClickListener { dialog.dismiss() }
        btnConfirm.setOnClickListener {
            val success = FileManager.deleteAudioFile(this, song.path)
            if (success) {
                Toast.makeText(this, "Archivo eliminado", Toast.LENGTH_SHORT).show()
                startScan()
            } else {
                Toast.makeText(this, "No se pudo eliminar el archivo", Toast.LENGTH_SHORT).show()
            }
            dialog.dismiss()
        }
        dialog.show()
    }

    private fun openPlaylistSongs(playlist: Playlist) {
        lifecycleScope.launch {
            val songIds = playlistManager.getSongIdsForPlaylist(playlist.id).toSet()
            val songsInPlaylist = allSongs.filter { songIds.contains(it.id) }
            val recycler: RecyclerView? = viewLibrary?.findViewById(R.id.recycler_library)
            recycler?.adapter = songAdapter
            songAdapter?.updateData(songsInPlaylist, favoriteSongIds)
            Toast.makeText(this@MainActivity, "${playlist.name} (${songsInPlaylist.size} temas)", Toast.LENGTH_SHORT).show()
        }
    }

    private fun refreshPlaylists() {
        lifecycleScope.launch {
            allPlaylists = playlistManager.getPlaylists()
            val countsMap = mutableMapOf<Long, Int>()
            for (p in allPlaylists) {
                countsMap[p.id] = playlistManager.getSongIdsForPlaylist(p.id).size
            }
            playlistCounts = countsMap
            playlistAdapter?.updateData(allPlaylists, playlistCounts)
        }
    }

    // ==========================================
    // PESTAÑA 3: EXPLORADOR DE CARPETAS
    // ==========================================
    private fun showExplorerTab() {
        fragmentContainer.removeAllViews()
        if (viewExplorer == null) {
            viewExplorer = layoutInflater.inflate(R.layout.fragment_explorer, fragmentContainer, false)
            setupExplorerTabViews(viewExplorer!!)
        }
        fragmentContainer.addView(viewExplorer)
        loadExplorerDirectory(currentExplorerDir)
    }

    private fun setupExplorerTabViews(v: View) {
        val recycler: RecyclerView = v.findViewById(R.id.recycler_explorer)
        val btnUp: ImageButton = v.findViewById(R.id.btn_folder_up)

        recycler.layoutManager = LinearLayoutManager(this)
        folderAdapter = FolderAdapter(this, emptyList()) { selectedFile ->
            if (selectedFile.isDirectory) {
                loadExplorerDirectory(selectedFile)
            } else {
                // Si es archivo de audio, reproducir
                val song = allSongs.find { it.path == selectedFile.absolutePath }
                    ?: Song(
                        id = selectedFile.hashCode().toLong(),
                        title = selectedFile.nameWithoutExtension,
                        artist = selectedFile.parentFile?.name ?: "Local",
                        album = "Explorador",
                        duration = 180000L,
                        path = selectedFile.absolutePath,
                        size = selectedFile.length()
                    )
                musicService?.setPlaylist(listOf(song), 0)
            }
        }
        recycler.adapter = folderAdapter

        btnUp.setOnClickListener {
            val parent = currentExplorerDir.parentFile
            if (parent != null && parent.canRead()) {
                loadExplorerDirectory(parent)
            }
        }
    }

    private fun loadExplorerDirectory(dir: File) {
        currentExplorerDir = dir
        val tvPath: TextView? = viewExplorer?.findViewById(R.id.tv_current_path)
        tvPath?.text = dir.absolutePath

        val files = dir.listFiles()?.filter {
            !it.name.startsWith(".") && (it.isDirectory || it.extension.lowercase() in setOf("mp3", "flac", "wav", "m4a", "ogg"))
        }?.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() })) ?: emptyList()

        folderAdapter?.updateData(files)

        val tvEmpty: TextView? = viewExplorer?.findViewById(R.id.tv_explorer_empty)
        tvEmpty?.visibility = if (files.isEmpty()) View.VISIBLE else View.GONE
    }

    // ==========================================
    // PESTAÑA 4: ECUALIZADOR DSP
    // ==========================================
    private fun showEqualizerTab() {
        fragmentContainer.removeAllViews()
        if (viewEqualizer == null) {
            viewEqualizer = layoutInflater.inflate(R.layout.fragment_equalizer, fragmentContainer, false)
            setupEqualizerTabViews(viewEqualizer!!)
        }
        fragmentContainer.addView(viewEqualizer)
    }

    private fun setupEqualizerTabViews(v: View) {
        val eq = musicService?.equalizer
        val bass = musicService?.bassBoost
        val virt = musicService?.virtualizer

        val switchEq: SwitchMaterial = v.findViewById(R.id.switch_eq_enable)
        val spinner: Spinner = v.findViewById(R.id.spinner_eq_presets)
        val seekBass: SeekBar = v.findViewById(R.id.seek_bass_boost)
        val seekVirt: SeekBar = v.findViewById(R.id.seek_virtualizer)

        switchEq.isChecked = eq?.enabled == true
        switchEq.setOnCheckedChangeListener { _, isChecked ->
            eq?.enabled = isChecked
            bass?.enabled = isChecked
            virt?.enabled = isChecked
        }

        seekBass.progress = bass?.roundedStrength?.toInt() ?: 400
        seekBass.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, prog: Int, user: Boolean) {
                if (user) bass?.setStrength(prog.toShort())
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        seekVirt.progress = virt?.roundedStrength?.toInt() ?: 350
        seekVirt.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, prog: Int, user: Boolean) {
                if (user) virt?.setStrength(prog.toShort())
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }

    // ==========================================
    // PESTAÑA 5: AJUSTES
    // ==========================================
    private fun showSettingsTab() {
        fragmentContainer.removeAllViews()
        if (viewSettings == null) {
            viewSettings = layoutInflater.inflate(R.layout.fragment_settings, fragmentContainer, false)
            setupSettingsTabViews(viewSettings!!)
        }
        fragmentContainer.addView(viewSettings)
    }

    private fun setupSettingsTabViews(v: View) {
        val prefs = getSharedPreferences("novaplayer_prefs", Context.MODE_PRIVATE)
        val switchLock: SwitchMaterial = v.findViewById(R.id.switch_lockscreen)
        val switchGap: SwitchMaterial = v.findViewById(R.id.switch_gapless)
        val cardRescan: MaterialCardView = v.findViewById(R.id.card_rescan)

        switchLock.isChecked = prefs.getBoolean("lockscreen_enabled", true)
        switchGap.isChecked = prefs.getBoolean("gapless_enabled", true)

        switchLock.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("lockscreen_enabled", checked).apply()
        }

        switchGap.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("gapless_enabled", checked).apply()
        }

        cardRescan.setOnClickListener {
            startScan()
        }
    }

    // ==========================================
    // ESCANEO AUTOMÁTICO DE MÚSICA
    // ==========================================
    private fun startScan() {
        val progress = viewLibrary?.findViewById<ProgressBar>(R.id.progress_scanning)
        progress?.visibility = View.VISIBLE

        lifecycleScope.launch {
            val scannedSongs = AutoScanner.scanMusic(this@MainActivity)
            allSongs = scannedSongs
            favoriteSongIds = favoriteManager.getFavoriteSongIds()

            withContext(Dispatchers.Main) {
                progress?.visibility = View.GONE
                songAdapter?.updateData(allSongs, favoriteSongIds)

                val emptyLayout = viewLibrary?.findViewById<View>(R.id.layout_empty_state)
                emptyLayout?.visibility = if (allSongs.isEmpty()) View.VISIBLE else View.GONE

                // Si el servicio no tiene lista aún, configurar lista completa
                if (musicService?.songList.isNullOrEmpty() && allSongs.isNotEmpty()) {
                    musicService?.setPlaylist(allSongs, 0)
                }

                refreshPlaylists()
                Toast.makeText(this@MainActivity, "Música sincronizada: ${allSongs.size} canciones", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ==========================================
    // CALLBACKS DE REPRODUCCIÓN
    // ==========================================
    override fun onSongChanged(song: Song?) {
        updateMiniPlayer(song, musicService?.isPlaying() == true)
        updatePlayerTabView(song, musicService?.isPlaying() == true)
    }

    override fun onPlaybackStateChanged(isPlaying: Boolean) {
        updateMiniPlayer(musicService?.getCurrentSong(), isPlaying)
        updatePlayerTabView(musicService?.getCurrentSong(), isPlaying)
    }

    override fun onProgressUpdate(currentMs: Int, totalMs: Int) {}

    private fun updateMiniPlayer(song: Song?, isPlaying: Boolean) {
        runOnUiThread {
            if (song != null) {
                miniTitle.text = song.title
                miniArtist.text = song.artist
            } else {
                miniTitle.text = getString(R.string.no_song_playing)
                miniArtist.text = getString(R.string.unknown_artist)
            }
            miniBtnPlayPause.setImageResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PermissionManager.REQUEST_CODE_PERMISSIONS) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            if (granted) {
                startScan()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isBound) {
            musicService?.unregisterListener(this)
            unbindService(connection)
            isBound = false
        }
    }
}
