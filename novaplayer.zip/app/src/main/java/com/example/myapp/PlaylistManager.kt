package com.example.myapp

import android.content.Context
import android.util.Log

/**
 * Gestor de listas de reproducción respaldado por Room.
 */
class PlaylistManager(context: Context) {

    private val playlistDao = AppDatabase.getDatabase(context).playlistDao()
    private val TAG = "PlaylistManager"

    suspend fun getPlaylists(): List<Playlist> {
        return try {
            playlistDao.getAllPlaylists()
        } catch (e: Exception) {
            Log.e(TAG, "Error obteniendo playlists", e)
            emptyList()
        }
    }

    suspend fun createPlaylist(name: String): Long {
        return try {
            val playlist = Playlist(name = name)
            playlistDao.insertPlaylist(playlist)
        } catch (e: Exception) {
            Log.e(TAG, "Error creando playlist: $name", e)
            -1L
        }
    }

    suspend fun deletePlaylist(playlistId: Long) {
        try {
            playlistDao.clearSongsForPlaylist(playlistId)
            playlistDao.deletePlaylist(playlistId)
        } catch (e: Exception) {
            Log.e(TAG, "Error eliminando playlist: $playlistId", e)
        }
    }

    suspend fun addSongToPlaylist(playlistId: Long, songId: Long) {
        try {
            playlistDao.addSongToPlaylist(PlaylistSongCrossRef(playlistId, songId))
        } catch (e: Exception) {
            Log.e(TAG, "Error agregando canción $songId a playlist $playlistId", e)
        }
    }

    suspend fun removeSongFromPlaylist(playlistId: Long, songId: Long) {
        try {
            playlistDao.removeSongFromPlaylist(playlistId, songId)
        } catch (e: Exception) {
            Log.e(TAG, "Error quitando canción $songId de playlist $playlistId", e)
        }
    }

    suspend fun getSongIdsForPlaylist(playlistId: Long): List<Long> {
        return try {
            playlistDao.getSongIdsForPlaylist(playlistId)
        } catch (e: Exception) {
            Log.e(TAG, "Error obteniendo canciones de playlist: $playlistId", e)
            emptyList()
        }
    }
}
