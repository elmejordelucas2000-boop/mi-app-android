package com.example.myapp.lockscreen

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

/**
 * Receptor para detectar el apagado de la pantalla (SCREEN_OFF)
 * y levantar la pantalla de bloqueo personalizada de NovaPlayer si se está reproduciendo música.
 */
class LockScreenReceiver : BroadcastReceiver() {

    private val TAG = "LockScreenReceiver"

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (Intent.ACTION_SCREEN_OFF == action) {
            try {
                val prefs = context.getSharedPreferences("novaplayer_prefs", Context.MODE_PRIVATE)
                val lockscreenEnabled = prefs.getBoolean("lockscreen_enabled", true)

                if (lockscreenEnabled) {
                    val lockIntent = Intent(context, LockScreenActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                        addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    }
                    context.startActivity(lockIntent)
                    Log.d(TAG, "Lanzando LockScreenActivity tras apagado de pantalla.")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error iniciando LockScreenActivity", e)
            }
        }
    }
}
