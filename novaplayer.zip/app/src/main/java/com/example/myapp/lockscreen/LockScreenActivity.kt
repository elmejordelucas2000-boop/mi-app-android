package com.example.myapp.lockscreen

import android.app.KeyguardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.util.Log
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.R
import com.example.myapp.MusicService
import com.example.myapp.Song
import com.google.android.material.button.MaterialButton

/**
 * Pantalla de Bloqueo personalizada estilo Poweramp con botón de Desbloqueo.
 */
class LockScreenActivity : AppCompatActivity(), MusicService.OnPlaybackChangeListener {

    private val TAG = "LockScreenActivity"

    private var musicService: MusicService? = null
    private var isBound = false

    private lateinit var tvTitle: TextView
    private lateinit var tvArtist: TextView
    private lateinit var imgAlbumArt: ImageView
    private lateinit var btnPlayPause: ImageButton
    private lateinit var btnPrev: ImageButton
    private lateinit var btnNext: ImageButton
    private lateinit var btnUnlock: MaterialButton

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as? MusicService.MusicBinder
            musicService = binder?.getService()
            isBound = true
            musicService?.registerListener(this@LockScreenActivity)
            updateUI(musicService?.getCurrentSong(), musicService?.isPlaying() == true)
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            musicService = null
            isBound = false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Configuración para mostrar sobre la pantalla de bloqueo del sistema
        configureLockScreenFlags()

        setContentView(R.layout.activity_lock_screen)

        tvTitle = findViewById(R.id.tv_lock_title)
        tvArtist = findViewById(R.id.tv_lock_artist)
        imgAlbumArt = findViewById(R.id.img_lock_album_art)
        btnPlayPause = findViewById(R.id.lock_btn_play_pause)
        btnPrev = findViewById(R.id.lock_btn_prev)
        btnNext = findViewById(R.id.lock_btn_next)
        btnUnlock = findViewById(R.id.btn_unlock)

        setupListeners()
    }

    private fun configureLockScreenFlags() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                setShowWhenLocked(true)
                setTurnScreenOn(true)
            } else {
                @Suppress("DEPRECATION")
                window.addFlags(
                    WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                            WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
                            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error configurando flags de bloqueo", e)
        }
    }

    private fun setupListeners() {
        btnPlayPause.setOnClickListener {
            musicService?.togglePlayPause()
        }

        btnPrev.setOnClickListener {
            musicService?.previous()
        }

        btnNext.setOnClickListener {
            musicService?.next()
        }

        btnUnlock.setOnClickListener {
            unlockDevice()
        }
    }

    private fun unlockDevice() {
        try {
            val keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                keyguardManager?.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
                    override fun onDismissSucceeded() {
                        super.onDismissSucceeded()
                        finish()
                    }

                    override fun onDismissCancelled() {
                        super.onDismissCancelled()
                        finish()
                    }
                })
            } else {
                finish()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error desbloqueando pantalla", e)
            finish()
        }
    }

    private fun updateUI(song: Song?, isPlaying: Boolean) {
        runOnUiThread {
            try {
                if (song != null) {
                    tvTitle.text = song.title
                    tvArtist.text = song.artist
                } else {
                    tvTitle.text = getString(R.string.no_song_playing)
                    tvArtist.text = getString(R.string.app_name)
                }

                val playPauseRes = if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play
                btnPlayPause.setImageResource(playPauseRes)
            } catch (e: Exception) {
                Log.e(TAG, "Error actualizando UI de bloqueo", e)
            }
        }
    }

    override fun onSongChanged(song: Song?) {
        updateUI(song, musicService?.isPlaying() == true)
    }

    override fun onPlaybackStateChanged(isPlaying: Boolean) {
        updateUI(musicService?.getCurrentSong(), isPlaying)
    }

    override fun onProgressUpdate(currentMs: Int, totalMs: Int) {
        // No necesario en lockscreen
    }

    override fun onStart() {
        super.onStart()
        val intent = Intent(this, MusicService::class.java)
        bindService(intent, connection, Context.BIND_AUTO_CREATE)
    }

    override fun onStop() {
        super.onStop()
        if (isBound) {
            musicService?.unregisterListener(this)
            unbindService(connection)
            isBound = false
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // En pantalla de bloqueo, el botón back desbloquea o minimiza
        unlockDevice()
    }
}
