package com.example.myapp

import android.os.Parcelable
import java.io.File

/**
 * Modelo de datos para una pista de audio en NovaPlayer.
 */
data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val duration: Long,
    val path: String,
    val albumId: Long = 0,
    val size: Long = 0,
    val dateAdded: Long = 0
) {
    /**
     * Devuelve la duración formateada en mm:ss
     */
    fun getFormattedDuration(): String {
        return try {
            val totalSeconds = duration / 1000
            val minutes = totalSeconds / 60
            val seconds = totalSeconds % 60
            String.format("%02d:%02d", minutes, seconds)
        } catch (e: Exception) {
            "00:00"
        }
    }

    /**
     * Nombre del archivo o extensión de audio
     */
    fun getExtension(): String {
        return try {
            val file = File(path)
            file.extension.uppercase()
        } catch (e: Exception) {
            "AUDIO"
        }
    }
}
