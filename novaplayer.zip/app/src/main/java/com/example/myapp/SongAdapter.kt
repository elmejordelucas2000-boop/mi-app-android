package com.example.myapp

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.widget.PopupMenu
import androidx.recyclerview.widget.RecyclerView
import com.example.R

/**
 * Adaptador de canciones para el RecyclerView de la Biblioteca.
 */
class SongAdapter(
    private val context: Context,
    private var songs: List<Song>,
    private var favoriteIds: Set<Long>,
    private val onSongClick: (Song, Int) -> Unit,
    private val onFavoriteClick: (Song) -> Unit,
    private val onOptionClick: (Song, Int) -> Unit // Action ID from popup menu
) : RecyclerView.Adapter<SongAdapter.SongViewHolder>() {

    fun updateData(newSongs: List<Song>, newFavoriteIds: Set<Long>) {
        this.songs = newSongs
        this.favoriteIds = newFavoriteIds
        notifyDataSetChanged()
    }

    fun updateFavorites(newFavoriteIds: Set<Long>) {
        this.favoriteIds = newFavoriteIds
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SongViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_song, parent, false)
        return SongViewHolder(view)
    }

    override fun onBindViewHolder(holder: SongViewHolder, position: Int) {
        val song = songs[position]
        holder.bind(song, favoriteIds.contains(song.id))
    }

    override fun getItemCount(): Int = songs.size

    inner class SongViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvTitle: TextView = itemView.findViewById(R.id.tv_item_title)
        private val tvArtist: TextView = itemView.findViewById(R.id.tv_item_artist)
        private val tvDuration: TextView = itemView.findViewById(R.id.tv_item_duration)
        private val imgArt: ImageView = itemView.findViewById(R.id.img_item_art)
        private val btnFavorite: ImageButton = itemView.findViewById(R.id.btn_item_favorite)
        private val btnMore: ImageButton = itemView.findViewById(R.id.btn_item_more)

        fun bind(song: Song, isFavorite: Boolean) {
            tvTitle.text = song.title
            tvArtist.text = "${song.artist} • ${song.album}"
            tvDuration.text = song.getFormattedDuration()

            // Icono de favorito
            if (isFavorite) {
                btnFavorite.setImageResource(R.drawable.ic_favorite_filled)
                btnFavorite.setColorFilter(context.getColor(R.color.favorite_red))
            } else {
                btnFavorite.setImageResource(R.drawable.ic_favorite)
                btnFavorite.setColorFilter(context.getColor(R.color.text_secondary))
            }

            itemView.setOnClickListener {
                onSongClick(song, bindingAdapterPosition)
            }

            btnFavorite.setOnClickListener {
                onFavoriteClick(song)
            }

            btnMore.setOnClickListener { view ->
                showPopupMenu(view, song)
            }
        }

        private fun showPopupMenu(view: View, song: Song) {
            val popup = PopupMenu(context, view)
            popup.menuInflater.inflate(R.menu.menu_song_options, popup.menu)
            popup.setOnMenuItemClickListener { item ->
                onOptionClick(song, item.itemId)
                true
            }
            popup.show()
        }
    }
}
