package com.example.myapp

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.lifecycleScope
import com.example.R
import com.google.android.material.card.MaterialCardView
import com.google.android.material.switchmaterial.SwitchMaterial
import kotlinx.coroutines.launch

/**
 * Actividad de Ajustes para NovaPlayer.
 */
class SettingsActivity : AppCompatActivity() {

    private lateinit var switchLockscreen: SwitchMaterial
    private lateinit var switchGapless: SwitchMaterial
    private lateinit var cardRescan: MaterialCardView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val toolbar: Toolbar = findViewById(R.id.toolbar_settings)
        toolbar.setNavigationOnClickListener { finish() }

        val prefs = getSharedPreferences("novaplayer_prefs", Context.MODE_PRIVATE)

        switchLockscreen = findViewById(R.id.switch_lockscreen)
        switchGapless = findViewById(R.id.switch_gapless)
        cardRescan = findViewById(R.id.card_rescan)

        switchLockscreen.isChecked = prefs.getBoolean("lockscreen_enabled", true)
        switchGapless.isChecked = prefs.getBoolean("gapless_enabled", true)

        switchLockscreen.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("lockscreen_enabled", isChecked).apply()
        }

        switchGapless.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("gapless_enabled", isChecked).apply()
        }

        cardRescan.setOnClickListener {
            Toast.makeText(this, getString(R.string.scanning), Toast.LENGTH_SHORT).show()
            lifecycleScope.launch {
                val songs = AutoScanner.scanMusic(this@SettingsActivity)
                Toast.makeText(
                    this@SettingsActivity,
                    getString(R.string.scan_completed, songs.size),
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }
}
