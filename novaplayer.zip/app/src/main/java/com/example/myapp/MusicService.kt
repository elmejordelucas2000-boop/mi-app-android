package com.example.myapp

import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import android.net.Uri
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import com.example.myapp.widget.WidgetHelper
import java.io.File
import java.io.FileOutputStream
import java.util.Random

/**
 * Servicio Foreground principal para reproducción de música estilo Poweramp.
 */
class MusicService : Service(),
    MediaPlayer.OnPreparedListener,
    MediaPlayer.OnCompletionListener,
    MediaPlayer.OnErrorListener,
    AudioManager.OnAudioFocusChangeListener {

    inner class MusicBinder : Binder() {
        fun getService(): MusicService = this@MusicService
    }

    private val binder = MusicBinder()

    // Reproductor de Medios
    private var mediaPlayer: MediaPlayer? = null
    private var audioManager: AudioManager? = null
    private var focusRequest: AudioFocusRequest? = null

    // Efectos DSP de Audio estilo Poweramp
    var equalizer: Equalizer? = null
        private set
    var bassBoost: BassBoost? = null
        private set
    var virtualizer: Virtualizer? = null
        private set

    // Estado de la Lista de Reproducción
    var songList: MutableList<Song> = mutableListOf()
        private set
    var currentSongIndex: Int = -1
        private set
    var isShuffle: Boolean = false
    var repeatMode: RepeatMode = RepeatMode.ALL

    enum class RepeatMode {
        OFF, ALL, ONE
    }

    // MediaSession y Notificación
    private var mediaSessionManager: MediaSessionManager? = null

    // Interfaz de escucha para Activities
    interface OnPlaybackChangeListener {
        fun onSongChanged(song: Song?)
        fun onPlaybackStateChanged(isPlaying: Boolean)
        fun onProgressUpdate(currentMs: Int, totalMs: Int)
    }

    private val listeners = mutableListOf<OnPlaybackChangeListener>()

    fun registerListener(listener: OnPlaybackChangeListener) {
        if (!listeners.contains(listener)) {
            listeners.add(listener)
            // Emitir estado actual inmediatamente
            listener.onSongChanged(getCurrentSong())
            listener.onPlaybackStateChanged(isPlaying())
        }
    }

    fun unregisterListener(listener: OnPlaybackChangeListener) {
        listeners.remove(listener)
    }

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "MusicService creado")

        try {
            audioManager = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            mediaSessionManager = MediaSessionManager(this)
            initMediaPlayer()
        } catch (e: Exception) {
            Log.e(TAG, "Error inicializando MusicService", e)
        }
    }

    private fun initMediaPlayer() {
        try {
            mediaPlayer?.release()
            mediaPlayer = MediaPlayer().apply {
                setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setOnPreparedListener(this@MusicService)
                setOnCompletionListener(this@MusicService)
                setOnErrorListener(this@MusicService)
            }
            initAudioEffects()
        } catch (e: Exception) {
            Log.e(TAG, "Error configurando MediaPlayer", e)
        }
    }

    private fun initAudioEffects() {
        try {
            val sessionId = mediaPlayer?.audioSessionId ?: 0
            if (sessionId != 0) {
                // Ecualizador
                equalizer?.release()
                equalizer = Equalizer(0, sessionId).apply {
                    enabled = true
                }

                // Refuerzo de graves (Bass Boost)
                bassBoost?.release()
                bassBoost = BassBoost(0, sessionId).apply {
                    enabled = true
                    if (strengthSupported) {
                        setStrength(400.toShort())
                    }
                }

                // Virtualizador 3D
                virtualizer?.release()
                virtualizer = Virtualizer(0, sessionId).apply {
                    enabled = true
                    if (strengthSupported) {
                        setStrength(350.toShort())
                    }
                }
                Log.d(TAG, "Efectos DSP de audio inicializados en sesión $sessionId")
            }
        } catch (e: Exception) {
            Log.e(TAG, "No se pudieron inicializar los efectos de audio", e)
        }
    }

    fun setPlaylist(songs: List<Song>, startIndex: Int = 0) {
        songList.clear()
        songList.addAll(songs)
        if (startIndex in songList.indices) {
            currentSongIndex = startIndex
            playSong(songList[startIndex])
        }
    }

    fun playSong(song: Song) {
        try {
            if (mediaPlayer == null) {
                initMediaPlayer()
            }
            mediaPlayer?.reset()

            // Manejo de pista real o muestra demo generada
            val actualPath = if (song.path.startsWith("demo_track")) {
                getOrCreateDemoWav(song.title)
            } else {
                song.path
            }

            val file = File(actualPath)
            if (file.exists()) {
                mediaPlayer?.setDataSource(actualPath)
            } else {
                // Intentar mediante Uri
                mediaPlayer?.setDataSource(applicationContext, Uri.parse(actualPath))
            }

            mediaPlayer?.prepareAsync()
        } catch (e: Exception) {
            Log.e(TAG, "Error cargando canción: ${song.title}", e)
            next()
        }
    }

    override fun onPrepared(mp: MediaPlayer?) {
        try {
            if (requestAudioFocus()) {
                mp?.start()
                updateNotificationAndWidgets(true)
                notifyPlaybackChanged(true)
                notifySongChanged(getCurrentSong())
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error iniciando reproducción en onPrepared", e)
        }
    }

    fun play() {
        try {
            if (mediaPlayer != null && !mediaPlayer!!.isPlaying) {
                if (requestAudioFocus()) {
                    mediaPlayer?.start()
                    updateNotificationAndWidgets(true)
                    notifyPlaybackChanged(true)
                }
            } else if (currentSongIndex in songList.indices) {
                playSong(songList[currentSongIndex])
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error en play()", e)
        }
    }

    fun pause() {
        try {
            if (mediaPlayer != null && mediaPlayer!!.isPlaying) {
                mediaPlayer?.pause()
                updateNotificationAndWidgets(false)
                notifyPlaybackChanged(false)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error en pause()", e)
        }
    }

    fun togglePlayPause() {
        if (isPlaying()) {
            pause()
        } else {
            play()
        }
    }

    fun next() {
        if (songList.isEmpty()) return

        if (isShuffle) {
            currentSongIndex = Random().nextInt(songList.size)
        } else {
            currentSongIndex = (currentSongIndex + 1) % songList.size
        }
        playSong(songList[currentSongIndex])
    }

    fun previous() {
        if (songList.isEmpty()) return

        val currentPos = getCurrentPosition()
        if (currentPos > 3000) {
            // Si ya pasaron más de 3 segundos, reiniciar la misma canción
            seekTo(0)
        } else {
            if (isShuffle) {
                currentSongIndex = Random().nextInt(songList.size)
            } else {
                currentSongIndex = if (currentSongIndex - 1 < 0) songList.size - 1 else currentSongIndex - 1
            }
            playSong(songList[currentSongIndex])
        }
    }

    fun seekTo(positionMs: Int) {
        try {
            mediaPlayer?.seekTo(positionMs)
            mediaSessionManager?.updatePlaybackState(isPlaying(), positionMs.toLong())
        } catch (e: Exception) {
            Log.e(TAG, "Error en seekTo", e)
        }
    }

    fun isPlaying(): Boolean {
        return try {
            mediaPlayer?.isPlaying == true
        } catch (e: Exception) {
            false
        }
    }

    fun getCurrentSong(): Song? {
        return if (currentSongIndex in songList.indices) songList[currentSongIndex] else null
    }

    fun getCurrentPosition(): Int {
        return try {
            mediaPlayer?.currentPosition ?: 0
        } catch (e: Exception) {
            0
        }
    }

    fun getDuration(): Int {
        return try {
            val dur = mediaPlayer?.duration ?: 0
            if (dur > 0) dur else (getCurrentSong()?.duration?.toInt() ?: 0)
        } catch (e: Exception) {
            getCurrentSong()?.duration?.toInt() ?: 0
        }
    }

    override fun onCompletion(mp: MediaPlayer?) {
        try {
            when (repeatMode) {
                RepeatMode.ONE -> {
                    seekTo(0)
                    play()
                }
                RepeatMode.ALL -> {
                    next()
                }
                RepeatMode.OFF -> {
                    if (currentSongIndex < songList.size - 1) {
                        next()
                    } else {
                        pause()
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error en onCompletion", e)
        }
    }

    override fun onError(mp: MediaPlayer?, what: Int, extra: Int): Boolean {
        Log.e(TAG, "MediaPlayer error: what=$what, extra=$extra")
        initMediaPlayer()
        return true
    }

    private fun requestAudioFocus(): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                focusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setOnAudioFocusChangeListener(this)
                    .build()
                audioManager?.requestAudioFocus(focusRequest!!) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
            } else {
                @Suppress("DEPRECATION")
                audioManager?.requestAudioFocus(
                    this,
                    AudioManager.STREAM_MUSIC,
                    AudioManager.AUDIOFOCUS_GAIN
                ) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error solicitando AudioFocus", e)
            true
        }
    }

    override fun onAudioFocusChange(focusChange: Int) {
        when (focusChange) {
            AudioManager.AUDIOFOCUS_LOSS -> pause()
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> pause()
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> mediaPlayer?.setVolume(0.2f, 0.2f)
            AudioManager.AUDIOFOCUS_GAIN -> {
                mediaPlayer?.setVolume(1.0f, 1.0f)
                play()
            }
        }
    }

    private fun updateNotificationAndWidgets(isPlaying: Boolean) {
        try {
            val currentSong = getCurrentSong()
            val notification = mediaSessionManager?.buildNotification(currentSong, isPlaying)
            if (notification != null) {
                startForeground(NOTIFICATION_ID, notification)
            }
            mediaSessionManager?.updatePlaybackState(isPlaying, getCurrentPosition().toLong())
            mediaSessionManager?.updateMetadata(currentSong, null)

            // Actualizar widgets en pantalla de inicio
            WidgetHelper.updateAllWidgets(this, currentSong, isPlaying)
        } catch (e: Exception) {
            Log.e(TAG, "Error actualizando notificación y widgets", e)
        }
    }

    private fun notifyPlaybackChanged(isPlaying: Boolean) {
        for (l in listeners) {
            try {
                l.onPlaybackStateChanged(isPlaying)
            } catch (e: Exception) {
                Log.e(TAG, "Error en listener playbackChanged", e)
            }
        }
    }

    private fun notifySongChanged(song: Song?) {
        for (l in listeners) {
            try {
                l.onSongChanged(song)
            } catch (e: Exception) {
                Log.e(TAG, "Error en listener songChanged", e)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action != null) {
            when (action) {
                ACTION_TOGGLE_PLAY -> togglePlayPause()
                ACTION_PLAY -> play()
                ACTION_PAUSE -> pause()
                ACTION_NEXT -> next()
                ACTION_PREVIOUS -> previous()
            }
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onDestroy() {
        super.onDestroy()
        try {
            mediaPlayer?.release()
            equalizer?.release()
            bassBoost?.release()
            virtualizer?.release()
            mediaSessionManager?.release()
        } catch (e: Exception) {
            Log.e(TAG, "Error en onDestroy de MusicService", e)
        }
    }

    /**
     * Genera un archivo WAV armónico y relajante para pistas de demostración
     */
    private fun getOrCreateDemoWav(trackName: String): String {
        val cacheFile = File(cacheDir, "demo_${trackName.hashCode()}.wav")
        if (cacheFile.exists()) return cacheFile.absolutePath

        try {
            val sampleRate = 44100
            val durationSeconds = 4
            val numSamples = durationSeconds * sampleRate
            val sample = ShortArray(numSamples)

            // Generador de acordes estéticos estilo sintetizador analógico
            val baseFreq = when (Math.abs(trackName.hashCode()) % 4) {
                0 -> 220.0 // La 3
                1 -> 261.63 // Do 4
                2 -> 329.63 // Mi 4
                else -> 392.0 // Sol 4
            }

            for (i in 0 until numSamples) {
                val t = i.toDouble() / sampleRate
                val wave1 = Math.sin(2.0 * Math.PI * baseFreq * t)
                val wave2 = 0.5 * Math.sin(2.0 * Math.PI * (baseFreq * 1.5) * t)
                val wave3 = 0.25 * Math.sin(2.0 * Math.PI * (baseFreq * 2.0) * t)
                val combined = (wave1 + wave2 + wave3) / 1.75
                sample[i] = (combined * 16000).toInt().toShort()
            }

            val byteData = ByteArray(numSamples * 2)
            var idx = 0
            for (s in sample) {
                byteData[idx++] = (s.toInt() and 0xFF).toByte()
                byteData[idx++] = ((s.toInt() shr 8) and 0xFF).toByte()
            }

            FileOutputStream(cacheFile).use { fos ->
                writeWavHeader(fos, byteData.size, sampleRate, 1, 16)
                fos.write(byteData)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error creando demo WAV", e)
        }
        return cacheFile.absolutePath
    }

    private fun writeWavHeader(out: FileOutputStream, totalAudioLen: Int, sampleRate: Int, channels: Int, bitsPerSample: Int) {
        val totalDataLen = totalAudioLen + 36
        val byteRate = sampleRate * channels * (bitsPerSample / 8)
        val header = ByteArray(44)
        header[0] = 'R'.code.toByte()
        header[1] = 'I'.code.toByte()
        header[2] = 'F'.code.toByte()
        header[3] = 'F'.code.toByte()
        header[4] = (totalDataLen and 0xff).toByte()
        header[5] = ((totalDataLen shr 8) and 0xff).toByte()
        header[6] = ((totalDataLen shr 16) and 0xff).toByte()
        header[7] = ((totalDataLen shr 24) and 0xff).toByte()
        header[8] = 'W'.code.toByte()
        header[9] = 'A'.code.toByte()
        header[10] = 'V'.code.toByte()
        header[11] = 'E'.code.toByte()
        header[12] = 'f'.code.toByte()
        header[13] = 'm'.code.toByte()
        header[14] = 't'.code.toByte()
        header[15] = ' '.code.toByte()
        header[16] = 16
        header[17] = 0
        header[18] = 0
        header[19] = 0
        header[20] = 1
        header[21] = 0
        header[22] = channels.toByte()
        header[23] = 0
        header[24] = (sampleRate and 0xff).toByte()
        header[25] = ((sampleRate shr 8) and 0xff).toByte()
        header[26] = ((sampleRate shr 16) and 0xff).toByte()
        header[27] = ((sampleRate shr 24) and 0xff).toByte()
        header[28] = (byteRate and 0xff).toByte()
        header[29] = ((byteRate shr 8) and 0xff).toByte()
        header[30] = ((byteRate shr 16) and 0xff).toByte()
        header[31] = ((byteRate shr 24) and 0xff).toByte()
        header[32] = (channels * bitsPerSample / 8).toByte()
        header[33] = 0
        header[34] = bitsPerSample.toByte()
        header[35] = 0
        header[36] = 'd'.code.toByte()
        header[37] = 'a'.code.toByte()
        header[38] = 't'.code.toByte()
        header[39] = 'a'.code.toByte()
        header[40] = (totalAudioLen and 0xff).toByte()
        header[41] = ((totalAudioLen shr 8) and 0xff).toByte()
        header[42] = ((totalAudioLen shr 16) and 0xff).toByte()
        header[43] = ((totalAudioLen shr 24) and 0xff).toByte()
        out.write(header, 0, 44)
    }

    companion object {
        const val TAG = "MusicService"
        const val NOTIFICATION_ID = 404
        const val ACTION_TOGGLE_PLAY = "com.example.myapp.ACTION_TOGGLE_PLAY"
        const val ACTION_PLAY = "com.example.myapp.ACTION_PLAY"
        const val ACTION_PAUSE = "com.example.myapp.ACTION_PAUSE"
        const val ACTION_NEXT = "com.example.myapp.ACTION_NEXT"
        const val ACTION_PREVIOUS = "com.example.myapp.ACTION_PREVIOUS"
    }
}
