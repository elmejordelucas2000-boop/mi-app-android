package com.example.myapp

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/**
 * Gestor de permisos para almacenamiento, notificaciones y servicios.
 */
object PermissionManager {

    private const val TAG = "PermissionManager"
    const val REQUEST_CODE_PERMISSIONS = 1001

    /**
     * Obtiene la lista de permisos requeridos según la versión de Android
     */
    fun getRequiredPermissions(): Array<String> {
        val permissions = mutableListOf<String>()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // Android 13+
            permissions.add(Manifest.permission.READ_MEDIA_AUDIO)
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            // Android 12 e inferiores
            permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // Permiso opcional bluetooth para controles multimedia
            permissions.add(Manifest.permission.BLUETOOTH_CONNECT)
        }

        return permissions.toTypedArray()
    }

    /**
     * Verifica si todos los permisos críticos ya han sido concedidos
     */
    fun hasAllPermissions(context: Context): Boolean {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val readAudio = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.READ_MEDIA_AUDIO
                ) == PackageManager.PERMISSION_GRANTED
                return readAudio
            } else {
                val readStorage = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED
                return readStorage
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error verificando permisos", e)
            return false
        }
    }

    /**
     * Solicita todos los permisos faltantes a la actividad
     */
    fun requestPermissions(activity: Activity) {
        try {
            val missingPermissions = mutableListOf<String>()
            for (perm in getRequiredPermissions()) {
                if (ContextCompat.checkSelfPermission(activity, perm) != PackageManager.PERMISSION_GRANTED) {
                    missingPermissions.add(perm)
                }
            }

            if (missingPermissions.isNotEmpty()) {
                Log.d(TAG, "Solicitando permisos: $missingPermissions")
                ActivityCompat.requestPermissions(
                    activity,
                    missingPermissions.toTypedArray(),
                    REQUEST_CODE_PERMISSIONS
                )
            } else {
                Log.d(TAG, "Todos los permisos ya estaban concedidos.")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error al solicitar permisos", e)
        }
    }
}
